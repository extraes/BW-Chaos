"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = __importDefault(require("discord.js"));
const ws_1 = __importDefault(require("ws"));
const client = new discord_js_1.default.Client({ disableMentions: "everyone" });
const token = process.argv[2];
const channelID = process.argv[3];
var channel;
var numSet2;
var accummulated = [0, 0, 0, 0];
var chosenclient;
class FUCKYOUSERVER extends ws_1.default.Server {
    sendall(data, cb) {
        this.clients.forEach(CUNT => { CUNT.send(data, cb); });
    }
}
const ws = new FUCKYOUSERVER({ port: 8999 });
console.log("Channel ID: " + channelID);
client.on("ready", function () {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        console.log(`Bot ready: ${(_a = client.user) === null || _a === void 0 ? void 0 : _a.tag}`);
        channel = yield client.channels.fetch(channelID).catch(err => console.error(`${err}`));
        if (!channel) {
            client.destroy();
            chosenclient === null || chosenclient === void 0 ? void 0 : chosenclient.send("*Invalid channel ID!");
            console.log(`Channel with ID ${channelID} doesn't exist OR the bot doesn't have access to it.`);
            return console.log("The connection to the Discord API has been closed and the Node window will wait for you to close it.");
        }
        if (channel.type == "text" || channel.type == "news") {
            var ch = channel;
            console.log(`Fetched channel #${ch.name}`);
        }
    });
});
client.on("message", msg => {
    if (msg.channel != channel)
        return;
    var offset = 0;
    if (numSet2)
        offset = 4;
    var choice = parseInt(msg.content);
    if (numSet2)
        choice -= 4;
    if (!(choice == NaN || choice > 4 || choice < 1)) {
        accummulated[choice - 1]++;
    }
});
client.on("warn", warning => { console.warn(warning); });
client.login(token).catch(err => {
    console.error("Invalid token! Are you sure you put in a BOT token?");
    throw err;
});
ws.on("connection", clientsocket => {
    console.log("Recieved new connection!");
    if (numSet2 == undefined) {
        chosenclient = clientsocket;
        clientsocket.on("message", message => {
            console.log("Message from client: " + message);
            if (message.toString() == "Clock") {
                console.log("Recieved clock message!");
                numSet2 = true;
                setInterval(() => {
                    if (numSet2) {
                        console.log("Switching number set - use 1234");
                        numSet2 = false;
                    }
                    else {
                        console.log("Switching number set - use 5678");
                        numSet2 = true;
                    }
                    clientsocket.send(JSON.stringify(accummulated));
                    accummulated = [0, 0, 0, 0];
                }, 32000);
            }
        });
        clientsocket.on("close", () => {
            console.log("\n\nIt looks like you closed BONEWORKS. Since closing BW doesn't close this Node window, you can close it yourself.");
            console.log("Y'know, I could probably autoclose it, but I don't feel like it.\n\n");
        });
    }
});
process.on("exit", () => { console.log("Shutting down now"); ws.close(); client.destroy(); });
process.on("SIGTERM", () => { console.log("Shutting down now"); ws.close(); client.destroy(); });
process.on("SIGABRT", () => { console.log("Node crashed"); ws.close(); client.destroy(); });
process.on('uncaughtException', () => { console.log("Bot crashed"); ws.close(); client.destroy(); });
const sleep = (interval) => new Promise((deliver, renege) => {
    if (typeof interval != 'number' || interval < 1)
        deliver(new Date().getTime());
    try {
        setTimeout(() => {
            deliver(new Date().getTime());
        }, interval);
    }
    catch (exception) {
        renege(exception.message);
    }
});
